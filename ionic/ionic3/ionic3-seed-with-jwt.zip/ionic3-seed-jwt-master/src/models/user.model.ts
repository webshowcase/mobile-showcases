export class UserModel {
 
  public name: string;
  public email: string;
  public password: string;
  public confirm_password?: string;
   
}
