export class BookModel {
 
  public id?: number;
  public user_id?: number;
  public title: string;
  public author_name: string;
  public pages_count: string;
  public created_at?: string;
  public updated_at?: string;
   
}
